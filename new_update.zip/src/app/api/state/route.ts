import { NextResponse } from "next/server";
import { blankState, seedState } from "@/lib/seed";
import { readState, sanitize, summarize, writeState } from "@/lib/server-state";

export const dynamic = "force-dynamic";

export async function GET() {
  try {
    const state = await readState();
    return NextResponse.json({ ok: true, state, meta: summarize(state) });
  } catch (err) {
    console.error(err);
    return NextResponse.json({ ok: false, error: "خواندن داده ناموفق بود" }, { status: 500 });
  }
}

export async function PUT(req: Request) {
  try {
    const body = await req.json();
    const clean = sanitize(body);
    if (!clean) {
      return NextResponse.json({ ok: false, error: "ساختار داده نامعتبر است" }, { status: 400 });
    }
    const state = await writeState(clean);
    return NextResponse.json({ ok: true, state, meta: summarize(state) });
  } catch (err) {
    console.error(err);
    return NextResponse.json({ ok: false, error: "ذخیره داده ناموفق بود" }, { status: 500 });
  }
}

export async function POST(req: Request) {
  try {
    const body = (await req.json().catch(() => ({}))) as { action?: string };
    if (body.action === "reset-demo") {
      const state = await writeState(seedState(), { skipAutoBackup: true });
      return NextResponse.json({ ok: true, state });
    }
    if (body.action === "clear") {
      const current = await readState();
      const next = { ...blankState(), settings: current.settings, profile: current.profile };
      const state = await writeState(next, { skipAutoBackup: true });
      return NextResponse.json({ ok: true, state });
    }
    return NextResponse.json({ ok: false, error: "عملیات نامعتبر" }, { status: 400 });
  } catch (err) {
    console.error(err);
    return NextResponse.json({ ok: false, error: "عملیات ناموفق بود" }, { status: 500 });
  }
}
