export const APP_NAME = 'میزکار زندگی';
export const APP_TAGLINE = 'مدیریت یکپارچه زندگی: وظایف، تقویم، عادت‌ها، یادداشت‌ها و مالی اختیاری';
