'use client';

import Dashboard from '@/views/Dashboard';
import { useQuickAdd } from '@/lib/quick-add';

export default function HomePage() {
  const onQuickAdd = useQuickAdd();
  return <Dashboard onQuickAdd={onQuickAdd} />;
}
