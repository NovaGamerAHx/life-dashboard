'use client';

import Calendar from '@/views/Calendar';

export default function CalendarPage() {
  return <Calendar />;
}
