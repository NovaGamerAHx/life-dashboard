'use client';

import { Suspense } from 'react';
import Today from '@/views/Today';

export default function TodayPage() {
  return (
    <Suspense fallback={<div className="h-72 animate-pulse rounded-3xl bg-slate-200/70 dark:bg-white/5" />}>
      <Today />
    </Suspense>
  );
}
