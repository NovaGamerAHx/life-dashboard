'use client';

import Backlog from '@/views/Backlog';

export default function BacklogPage() {
  return <Backlog />;
}
