'use client';

import { createContext, useContext } from 'react';

export type QuickKind = 'tx' | 'task' | 'event' | 'note' | 'habit';

export const QuickAddContext = createContext<(k: QuickKind) => void>(() => {});

export function useQuickAdd() {
  return useContext(QuickAddContext);
}
