'use client';

import Finance from '@/views/Finance';
import { Navigate } from '@/lib/nav';
import { useApp } from '@/lib/store';

export default function FinancePage() {
  const { state, ready } = useApp();
  if (!ready) return null;
  if (!state.settings.financeEnabled) return <Navigate to="/settings" replace />;
  return <Finance />;
}
