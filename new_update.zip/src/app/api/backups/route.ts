import { NextResponse } from "next/server";
import { createBackup, deleteBackup, listBackups, readState, restoreBackup } from "@/lib/server-state";

export const dynamic = "force-dynamic";

export async function GET() {
  try {
    const backups = await listBackups();
    return NextResponse.json({ ok: true, backups });
  } catch (err) {
    console.error(err);
    return NextResponse.json({ ok: false, error: "خواندن پشتیبان‌ها ناموفق بود" }, { status: 500 });
  }
}

export async function POST(req: Request) {
  try {
    const body = (await req.json().catch(() => ({}))) as { label?: string; action?: string; id?: string };
    if (body.action === "restore" && body.id) {
      const state = await restoreBackup(body.id);
      if (!state) return NextResponse.json({ ok: false, error: "پشتیبان پیدا نشد" }, { status: 404 });
      return NextResponse.json({ ok: true, state });
    }
    const state = await readState();
    const backup = await createBackup(state, { label: body.label, auto: false });
    return NextResponse.json({ ok: true, backup });
  } catch (err) {
    console.error(err);
    return NextResponse.json({ ok: false, error: "ایجاد پشتیبان ناموفق بود" }, { status: 500 });
  }
}

export async function DELETE(req: Request) {
  try {
    const { searchParams } = new URL(req.url);
    const id = searchParams.get("id");
    if (!id) return NextResponse.json({ ok: false, error: "شناسه لازم است" }, { status: 400 });
    await deleteBackup(id);
    return NextResponse.json({ ok: true });
  } catch (err) {
    console.error(err);
    return NextResponse.json({ ok: false, error: "حذف پشتیبان ناموفق بود" }, { status: 500 });
  }
}
