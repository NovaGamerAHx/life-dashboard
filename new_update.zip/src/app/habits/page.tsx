'use client';

import Habits from '@/views/Habits';

export default function HabitsPage() {
  return <Habits />;
}
