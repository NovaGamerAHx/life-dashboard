import { bigint, boolean, jsonb, pgTable, text } from "drizzle-orm/pg-core";
import type { AppState } from "@/lib/types";

export const appStateTable = pgTable("app_state", {
  id: text("id").primaryKey(),
  payload: jsonb("payload").$type<AppState>().notNull(),
  updatedAt: bigint("updated_at", { mode: "number" }).notNull(),
});

export const backupsTable = pgTable("backups", {
  id: text("id").primaryKey(),
  label: text("label").notNull(),
  auto: boolean("auto").notNull().default(false),
  payload: jsonb("payload").$type<AppState>().notNull(),
  createdAt: bigint("created_at", { mode: "number" }).notNull(),
});
