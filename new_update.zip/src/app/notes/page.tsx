'use client';

import Notes from '@/views/Notes';

export default function NotesPage() {
  return <Notes />;
}
