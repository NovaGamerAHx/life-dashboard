import { desc, eq } from "drizzle-orm";
import { db } from "@/db";
import { appStateTable, backupsTable } from "@/db/schema";
import { blankState, seedState } from "@/lib/seed";
import type { AppSettings, AppState, DayReflection, Task, TaskCategory } from "@/lib/types";
import { uid } from "@/lib/utils";

export const STATE_ID = "default";
const MAX_AUTO_BACKUPS = 8;
const MAX_MANUAL_BACKUPS = 20;
const AUTO_BACKUP_EVERY_MS = 12 * 60 * 60 * 1000;

function sanitize(s: unknown): AppState | null {
  if (!s || typeof s !== "object") return null;
  const o = s as Partial<AppState>;
  if (o.version !== 1) return null;
  if (!Array.isArray(o.transactions) || !Array.isArray(o.tasks) || !Array.isArray(o.events)) return null;
  if (!Array.isArray(o.habits) || !Array.isArray(o.notes) || !Array.isArray(o.budgets)) return null;
  const base = blankState();
  return {
    ...base,
    ...(o as AppState),
    settings: {
      ...base.settings,
      ...(o.settings ?? {}),
      financeEnabled: (o.settings as Partial<AppSettings> | undefined)?.financeEnabled ?? false,
      weekStart: (o.settings as Partial<AppSettings> | undefined)?.weekStart ?? "sat",
      calSystem: (o.settings as Partial<AppSettings> | undefined)?.calSystem ?? "jalali",
    },
    taskCats: Array.isArray(o.taskCats) && o.taskCats.length > 0 ? (o.taskCats as TaskCategory[]) : base.taskCats,
    reflections: Array.isArray(o.reflections) ? (o.reflections as DayReflection[]) : [],
    habitLogs: o.habitLogs && typeof o.habitLogs === "object" ? o.habitLogs : {},
    tasks: ((o.tasks as Task[] | undefined) ?? []).map((t) => ({
      ...t,
      backlog: t.backlog ?? t.due == null,
      time: t.time ?? "",
      durationMin: t.durationMin ?? 60,
      urgent: t.urgent ?? t.priority === "high",
      deadline: t.deadline ?? null,
      actualMin: t.actualMin ?? undefined,
      result: t.result ?? undefined,
      subtasks: Array.isArray(t.subtasks) ? t.subtasks : [],
      tags: Array.isArray(t.tags) ? t.tags : [],
    })),
  };
}

export async function readState(): Promise<AppState> {
  const rows = await db.select().from(appStateTable).where(eq(appStateTable.id, STATE_ID)).limit(1);
  if (rows[0]?.payload) {
    const clean = sanitize(rows[0].payload);
    if (clean) return clean;
  }
  const seeded = seedState();
  await writeState(seeded, { skipAutoBackup: true });
  return seeded;
}

export async function writeState(state: AppState, opts?: { skipAutoBackup?: boolean }): Promise<AppState> {
  const clean = sanitize(state) ?? blankState();
  const now = Date.now();
  await db
    .insert(appStateTable)
    .values({ id: STATE_ID, payload: clean, updatedAt: now })
    .onConflictDoUpdate({
      target: appStateTable.id,
      set: { payload: clean, updatedAt: now },
    });

  if (!opts?.skipAutoBackup) {
    await maybeAutoBackup(clean, now);
  }
  return clean;
}

async function maybeAutoBackup(state: AppState, now: number) {
  const latestAuto = await db
    .select({ createdAt: backupsTable.createdAt })
    .from(backupsTable)
    .where(eq(backupsTable.auto, true))
    .orderBy(desc(backupsTable.createdAt))
    .limit(1);

  const last = latestAuto[0]?.createdAt ?? 0;
  if (now - last < AUTO_BACKUP_EVERY_MS) return;

  await createBackup(state, { label: "پشتیبان خودکار", auto: true });
}

export async function createBackup(state: AppState, opts?: { label?: string; auto?: boolean }) {
  const auto = opts?.auto ?? false;
  const row = {
    id: uid(auto ? "auto" : "bak"),
    label: opts?.label?.trim() || (auto ? "پشتیبان خودکار" : "پشتیبان دستی"),
    auto,
    payload: state,
    createdAt: Date.now(),
  };
  await db.insert(backupsTable).values(row);

  const all = await db
    .select({ id: backupsTable.id, auto: backupsTable.auto, createdAt: backupsTable.createdAt })
    .from(backupsTable)
    .orderBy(desc(backupsTable.createdAt));

  const autos = all.filter((b) => b.auto);
  const manuals = all.filter((b) => !b.auto);
  const extra = [...autos.slice(MAX_AUTO_BACKUPS), ...manuals.slice(MAX_MANUAL_BACKUPS)];
  for (const b of extra) {
    await db.delete(backupsTable).where(eq(backupsTable.id, b.id));
  }
  return { id: row.id, label: row.label, auto: row.auto, createdAt: row.createdAt };
}

export async function listBackups() {
  const rows = await db
    .select({
      id: backupsTable.id,
      label: backupsTable.label,
      auto: backupsTable.auto,
      createdAt: backupsTable.createdAt,
      payload: backupsTable.payload,
    })
    .from(backupsTable)
    .orderBy(desc(backupsTable.createdAt));

  return rows.map((r) => ({
    id: r.id,
    label: r.label,
    auto: r.auto,
    createdAt: r.createdAt,
    meta: summarize(r.payload),
  }));
}

export async function restoreBackup(id: string): Promise<AppState | null> {
  const rows = await db.select().from(backupsTable).where(eq(backupsTable.id, id)).limit(1);
  const payload = rows[0]?.payload;
  if (!payload) return null;
  return writeState(payload, { skipAutoBackup: true });
}

export async function deleteBackup(id: string) {
  await db.delete(backupsTable).where(eq(backupsTable.id, id));
}

export function summarize(s: AppState) {
  return {
    tasks: s.tasks?.length ?? 0,
    events: s.events?.length ?? 0,
    habits: s.habits?.length ?? 0,
    notes: s.notes?.length ?? 0,
    transactions: s.transactions?.length ?? 0,
    reflections: s.reflections?.length ?? 0,
    financeEnabled: !!s.settings?.financeEnabled,
  };
}

export { sanitize };
