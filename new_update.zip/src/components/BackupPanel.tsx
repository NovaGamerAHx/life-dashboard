'use client';

import { useCallback, useEffect, useState } from 'react';
import { Clock3, HardDrive, RotateCcw, Save, Trash2 } from 'lucide-react';
import { Btn, Card, CardHead, Confirm, inputCls } from '@/components/ui';
import { formatJalali, formatTime, toFa } from '@/lib/jalali';
import { useApp } from '@/lib/store';
import { cx } from '@/lib/utils';

type BackupRow = {
  id: string;
  label: string;
  auto: boolean;
  createdAt: number;
  meta?: {
    tasks: number;
    events: number;
    habits: number;
    notes: number;
    transactions: number;
    reflections: number;
  };
};

export function BackupPanel() {
  const { importState } = useApp();
  const [rows, setRows] = useState<BackupRow[]>([]);
  const [loading, setLoading] = useState(true);
  const [label, setLabel] = useState('');
  const [msg, setMsg] = useState<string | null>(null);
  const [restoreId, setRestoreId] = useState<string | null>(null);
  const [deleteId, setDeleteId] = useState<string | null>(null);

  const load = useCallback(async () => {
    try {
      const res = await fetch('/api/backups', { cache: 'no-store' });
      const data = await res.json();
      if (data?.ok) setRows(data.backups ?? []);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { void load(); }, [load]);

  const flash = (t: string) => {
    setMsg(t);
    setTimeout(() => setMsg(null), 2800);
  };

  const create = async () => {
    const res = await fetch('/api/backups', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ label: label.trim() || undefined }),
    });
    const data = await res.json();
    if (data?.ok) {
      setLabel('');
      flash('پشتیبان روی سرور ذخیره شد');
      await load();
    } else flash(data?.error || 'ذخیره پشتیبان ناموفق بود');
  };

  const restore = async (id: string) => {
    const res = await fetch('/api/backups', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ action: 'restore', id }),
    });
    const data = await res.json();
    if (data?.ok && data.state) {
      importState(data.state);
      flash('پشتیبان بازیابی شد');
    } else flash(data?.error || 'بازیابی ناموفق بود');
  };

  const remove = async (id: string) => {
    await fetch(`/api/backups?id=${encodeURIComponent(id)}`, { method: 'DELETE' });
    await load();
  };

  return (
    <Card>
      <CardHead
        title="بایگانی پشتیبان روی سرور"
        sub="نسخه‌های دستی و خودکار (هر ۱۲ ساعت) — تا ۲۰ نسخه دستی و ۸ نسخه خودکار"
      />
      <div className="space-y-3 px-5 pb-5">
        {msg && <p className="rounded-2xl bg-emerald-500/10 px-3 py-2 text-xs font-bold text-emerald-700 dark:text-emerald-300">{msg}</p>}
        <div className="flex flex-wrap gap-2">
          <input
            value={label}
            onChange={(e) => setLabel(e.target.value)}
            placeholder="نام پشتیبان (مثلاً قبل از سفر)"
            className={cx(inputCls, 'min-w-[180px] flex-1')}
          />
          <Btn onClick={() => void create()}><Save size={15} /> ذخیره نسخه فعلی</Btn>
        </div>
        {loading ? (
          <p className="text-xs text-slate-400">در حال بارگذاری…</p>
        ) : rows.length === 0 ? (
          <p className="rounded-2xl bg-slate-50 py-4 text-center text-xs text-slate-400 dark:bg-white/5">هنوز پشتیبانی روی سرور نیست</p>
        ) : (
          <ul className="space-y-1.5">
            {rows.map((b) => (
              <li key={b.id} className="flex flex-wrap items-center gap-2 rounded-2xl border border-slate-100 px-3 py-2.5 dark:border-white/5">
                <span className={cx('grid h-9 w-9 shrink-0 place-items-center rounded-xl', b.auto ? 'bg-sky-500/10 text-sky-600' : 'bg-emerald-500/10 text-emerald-600')}>
                  {b.auto ? <Clock3 size={16} /> : <HardDrive size={16} />}
                </span>
                <span className="min-w-0 flex-1">
                  <span className="block truncate text-[13px] font-bold text-slate-700 dark:text-slate-200">{b.label}</span>
                  <span className="block text-[11px] text-slate-400">
                    {formatJalali(b.createdAt, { weekday: false })} • {formatTime(b.createdAt)}
                    {b.meta ? ` • ${toFa(b.meta.tasks)} وظیفه، ${toFa(b.meta.notes)} یادداشت` : ''}
                  </span>
                </span>
                <button onClick={() => setRestoreId(b.id)} className="grid h-8 w-8 place-items-center rounded-lg text-slate-400 hover:bg-emerald-500/10 hover:text-emerald-600" title="بازیابی">
                  <RotateCcw size={14} />
                </button>
                <button onClick={() => setDeleteId(b.id)} className="grid h-8 w-8 place-items-center rounded-lg text-slate-400 hover:bg-rose-500/10 hover:text-rose-500" title="حذف">
                  <Trash2 size={14} />
                </button>
              </li>
            ))}
          </ul>
        )}
      </div>
      <Confirm open={restoreId != null} onClose={() => setRestoreId(null)} onYes={() => restoreId && void restore(restoreId)} title="بازیابی این پشتیبان؟" desc="داده‌های فعلی با این نسخه جایگزین می‌شود. می‌توانید قبلش یک پشتیبان جدید بگیرید." />
      <Confirm open={deleteId != null} onClose={() => setDeleteId(null)} onYes={() => deleteId && void remove(deleteId)} title="حذف پشتیبان؟" desc="این نسخه از بایگانی سرور پاک می‌شود." />
    </Card>
  );
}
