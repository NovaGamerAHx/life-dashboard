'use client';

import { useMemo, useState } from 'react';
import { Award, CalendarRange, CheckCircle2, Download, Flame, Heart, Lightbulb, Repeat } from 'lucide-react';
import { AreaChart, Bars, Donut, Legend } from '@/components/charts';
import { Card, CardHead, Progress, Segmented } from '@/components/ui';
import { addDays, formatJalali, J_MONTHS, startOfDay, toFa, toGregorian, toJalaali, todayStart } from '@/lib/jalali';
import { downloadText, exportRowsCsv, habitStreak, habitWeekCount } from '@/lib/stats';
import { useApp } from '@/lib/store';
import { cx } from '@/lib/utils';

const MOODS = ['😞', '😐', '🙂', '😄', '🤩'];

export function LifeKpis({ jy, jm }: { jy: number; jm: number }) {
  const { state } = useApp();
  const range = useMemo(() => monthRange(jy, jm), [jy, jm]);
  const monthTasks = state.tasks.filter((t) => !t.backlog && t.due != null && t.due >= range.start && t.due <= range.end);
  const done = monthTasks.filter((t) => t.status === 'done').length;
  const pct = monthTasks.length ? Math.round((done / monthTasks.length) * 100) : 0;
  const refs = (state.reflections ?? []).filter((r) => r.day >= range.start && r.day <= range.end);
  const avgMood = refs.length ? refs.reduce((a, r) => a + r.mood, 0) / refs.length : 0;
  const avgScore = (() => {
    const scored = refs.filter((r) => r.score != null);
    if (!scored.length) return null;
    return scored.reduce((a, r) => a + (r.score ?? 0), 0) / scored.length;
  })();
  const activeHabits = state.habits.filter((h) => !h.archived);
  const habitRate = activeHabits.length
    ? Math.round(
      (activeHabits.reduce((a, h) => a + habitWeekCount(h.id, state.habitLogs), 0) / (activeHabits.length * 7)) * 100,
    )
    : 0;

  return (
    <div className="grid grid-cols-2 gap-3 xl:grid-cols-4">
      <Kpi icon={<CheckCircle2 size={19} />} label="نرخ انجام ماه" value={`${toFa(pct)}٪`} sub={`${toFa(done)} از ${toFa(monthTasks.length)} تسک`} c="from-emerald-500 to-teal-600" />
      <Kpi icon={<Repeat size={19} />} label="عادت‌های هفته" value={`${toFa(habitRate)}٪`} sub={`${toFa(activeHabits.length)} عادت فعال`} c="from-sky-500 to-blue-600" />
      <Kpi icon={<Heart size={19} />} label="میانگین حال" value={refs.length ? `${MOODS[Math.round(avgMood) - 1] ?? '🙂'} ${toFa(avgMood.toFixed(1))}` : '—'} sub={`${toFa(refs.length)} بازتاب`} c="from-violet-500 to-purple-600" />
      <Kpi icon={<CalendarRange size={19} />} label="میانگین نمره روز" value={avgScore != null ? `${toFa(avgScore.toFixed(1))} از ۱۰` : 'ثبت نشده'} sub={J_MONTHS[jm - 1]} c="from-amber-500 to-orange-600" />
    </div>
  );
}

export function LifeReportBody({ jy, jm }: { jy: number; jm: number }) {
  const { state } = useApp();
  const range = useMemo(() => monthRange(jy, jm), [jy, jm]);
  const [rangeN, setRangeN] = useState<7 | 14 | 30>(14);
  const today = todayStart();
  const activeHabits = state.habits.filter((h) => !h.archived);

  const days = useMemo(() => {
    return Array.from({ length: rangeN }, (_, idx) => {
      const day = addDays(today, idx - (rangeN - 1));
      const ts = state.tasks.filter((t) => !t.backlog && t.due === day);
      const dn = ts.filter((t) => t.status === 'done').length;
      const ref = (state.reflections ?? []).find((r) => r.day === day);
      const hDone = activeHabits.filter((h) => state.habitLogs[`${h.id}:${day}`]).length;
      return {
        day,
        total: ts.length,
        done: dn,
        pct: ts.length ? Math.round((dn / ts.length) * 100) : 0,
        mood: ref?.mood ?? null,
        score: ref?.score ?? null,
        habits: hDone,
      };
    });
  }, [state.tasks, state.reflections, state.habitLogs, activeHabits, rangeN, today]);

  const habitRows = activeHabits.map((h) => ({
    h,
    streak: habitStreak(h.id, state.habitLogs),
    week: habitWeekCount(h.id, state.habitLogs),
    total: Object.keys(state.habitLogs).filter((k) => k.startsWith(h.id + ':') && state.habitLogs[k]).length,
  })).sort((a, b) => b.streak - a.streak);

  const catRows = useMemo(() => {
    const m = new Map<string, { total: number; done: number }>();
    for (const t of state.tasks.filter((x) => !x.backlog && x.due != null && x.due >= range.start && x.due <= range.end)) {
      const tags = t.tags.length ? t.tags : ['بدون دسته'];
      for (const tag of tags) {
        const e = m.get(tag) ?? { total: 0, done: 0 };
        e.total++;
        if (t.status === 'done') e.done++;
        m.set(tag, e);
      }
    }
    return [...m.entries()].map(([name, v]) => ({ name, ...v, pct: v.total ? Math.round((v.done / v.total) * 100) : 0 }))
      .sort((a, b) => b.total - a.total);
  }, [state.tasks, range]);

  const insights = useMemo(() => {
    const out: string[] = [];
    const withTasks = days.filter((d) => d.total > 0);
    const avg = withTasks.length ? Math.round(withTasks.reduce((a, d) => a + d.pct, 0) / withTasks.length) : 0;
    if (avg >= 80) out.push(`نرخ انجام ${toFa(avg)}٪ است — ریتم عالی را ادامه بده.`);
    else if (avg > 0) out.push(`میانگین انجام تسک در این بازه ${toFa(avg)}٪ است. هدف پیشنهادی: بالای ۷۰٪.`);
    const moods = days.filter((d) => d.mood != null);
    if (moods.length) {
      const am = moods.reduce((a, d) => a + (d.mood ?? 0), 0) / moods.length;
      out.push(`حال میانگین این بازه ${toFa(am.toFixed(1))} از ۵ بوده.`);
    }
    if (habitRows[0]?.streak) out.push(`بلندترین زنجیره الان «${habitRows[0].h.title}» با ${toFa(habitRows[0].streak)} روز است.`);
    const missed = days.filter((d) => d.day <= today && !(state.reflections ?? []).some((r) => r.day === d.day)).length;
    if (missed > 3) out.push(`${toFa(missed)} روز بدون بازتاب مانده — حتی یک خط هم کافی است.`);
    if (!out.length) out.push('با ثبت تسک، عادت و بازتاب، تحلیل هوشمند اینجا شکل می‌گیرد.');
    return out.slice(0, 5);
  }, [days, habitRows, state.reflections, today]);

  const exportLife = () => {
    const rows = days.map((d) => ({
      تاریخ: formatJalali(d.day),
      تسک_انجام: d.done,
      تسک_کل: d.total,
      درصد: d.pct,
      حال: d.mood ?? '',
      نمره: d.score ?? '',
      عادت: d.habits,
    }));
    downloadText(`life-report-${jy}-${jm}.csv`, exportRowsCsv(rows));
  };

  const donut = habitRows.slice(0, 6).map((r) => ({ label: r.h.title, value: r.week, color: r.h.color }));

  return (
    <div className="space-y-5">
      <div className="flex justify-end">
        <button onClick={exportLife} className="flex h-9 items-center gap-1.5 rounded-xl border border-slate-200 px-3 text-xs font-bold text-slate-500 transition hover:bg-slate-50 dark:border-white/10 dark:text-slate-300 dark:hover:bg-white/5">
          <Download size={14} /> خروجی CSV زندگی
        </button>
      </div>

      {insights.length > 0 && (
        <Card>
          <CardHead title="بینش‌های هوشمند" sub="تحلیل خودکار عادت‌ها، وظایف و بازتاب‌ها" />
          <ul className="space-y-2 px-5 pb-5">
            {insights.map((s, i) => (
              <li key={i} className="flex items-start gap-2.5 rounded-2xl bg-sky-500/[0.06] px-3.5 py-3 text-[12px] leading-6 text-slate-600 ring-1 ring-sky-500/15 dark:text-slate-300">
                <Lightbulb size={16} className="mt-0.5 shrink-0 text-sky-500" />
                {s}
              </li>
            ))}
          </ul>
        </Card>
      )}

      <div className="grid gap-5 xl:grid-cols-2">
        <Card>
          <CardHead
            title="روند انجام تسک"
            action={
              <Segmented
                value={String(rangeN) as '7' | '14' | '30'}
                onChange={(v) => setRangeN(Number(v) as 7 | 14 | 30)}
                options={[{ v: '7', label: '۷ روز' }, { v: '14', label: '۱۴ روز' }, { v: '30', label: '۳۰ روز' }]}
              />
            }
          />
          <div className="px-5 pb-5">
            <AreaChart
              values={days.map((d) => d.pct)}
              labels={days.map((d) => toFa(toJalaali(new Date(d.day)).jd))}
              color="#0ea5e9"
              height={140}
              idSuffix="life-pct"
            />
          </div>
        </Card>
        <Card>
          <CardHead title="عادت‌های هفته" sub="تعداد تیک نسبت به هدف" />
          <div className="flex flex-col items-center gap-4 px-5 pb-5">
            <Donut data={donut} size={170} centerTop="تیک هفته" centerBottom={toFa(donut.reduce((a, x) => a + x.value, 0))} />
            {donut.length > 0 ? <div className="w-full"><Legend items={donut} money={(v) => `${toFa(v)} روز`} /></div> : <p className="text-xs text-slate-400">عادتی فعال نیست</p>}
          </div>
        </Card>
      </div>

      <div className="grid gap-5 xl:grid-cols-2">
        <Card>
          <CardHead title="جدول عادت‌ها" sub="زنجیره، هفته و مجموع تیک‌ها" />
          <div className="overflow-x-auto px-5 pb-5">
            <table className="w-full min-w-[420px] text-right text-xs">
              <thead>
                <tr className="border-b border-slate-100 text-slate-400 dark:border-white/10">
                  <th className="py-2.5 font-bold">عادت</th>
                  <th className="py-2.5 font-bold">زنجیره</th>
                  <th className="py-2.5 font-bold">این هفته</th>
                  <th className="py-2.5 font-bold">کل</th>
                </tr>
              </thead>
              <tbody>
                {habitRows.map((r) => (
                  <tr key={r.h.id} className="border-b border-slate-50 last:border-0 dark:border-white/5">
                    <td className="py-2.5 font-black text-slate-700 dark:text-slate-200">
                      <span className="inline-flex items-center gap-1.5">
                        <span className="h-2.5 w-2.5 rounded-full" style={{ background: r.h.color }} />
                        {r.h.title}
                      </span>
                    </td>
                    <td className="tabular py-2.5 text-orange-500 font-bold">{toFa(r.streak)} روز</td>
                    <td className="tabular py-2.5 text-slate-500">{toFa(r.week)} / {toFa(r.h.targetPerWeek)}</td>
                    <td className="tabular py-2.5 text-slate-500">{toFa(r.total)}</td>
                  </tr>
                ))}
                {habitRows.length === 0 && (
                  <tr><td colSpan={4} className="py-8 text-center text-slate-400">عادتی ثبت نشده</td></tr>
                )}
              </tbody>
            </table>
          </div>
        </Card>
        <Card>
          <CardHead title="عملکرد دسته‌های وظیفه" sub="نرخ انجام هر برچسب در ماه انتخابی" />
          <div className="space-y-3 px-5 pb-5">
            {catRows.length === 0 && <p className="rounded-2xl bg-slate-50 py-4 text-center text-xs text-slate-400 dark:bg-white/5">در این ماه تسک زمان‌بندی‌شده‌ای نیست</p>}
            {catRows.slice(0, 8).map((r) => (
              <div key={r.name}>
                <div className="mb-1 flex justify-between text-xs font-bold">
                  <span className="text-slate-600 dark:text-slate-300">#{r.name}</span>
                  <span className="tabular text-slate-400">{toFa(r.done)}/{toFa(r.total)} • {toFa(r.pct)}٪</span>
                </div>
                <Progress value={r.pct} color={r.pct >= 80 ? '#10b981' : r.pct >= 50 ? '#f59e0b' : '#f43f5e'} />
              </div>
            ))}
          </div>
        </Card>
      </div>

      <Card>
        <CardHead title="رکوردهای زندگی" sub="نکات برجسته همین دوره" />
        <div className="grid grid-cols-2 gap-3 px-5 pb-5">
          <Record icon={<Flame size={18} />} label="بلندترین زنجیره" value={habitRows[0]?.h.title ?? '—'} sub={habitRows[0] ? `${toFa(habitRows[0].streak)} روز` : ''} c="bg-orange-500/10 text-orange-600" />
          <Record icon={<Award size={18} />} label="بهترین دسته" value={catRows[0]?.name ?? '—'} sub={catRows[0] ? `${toFa(catRows[0].pct)}٪ انجام` : ''} c="bg-emerald-500/10 text-emerald-600" />
          <Record icon={<Heart size={18} />} label="بازتاب‌های ماه" value={toFa((state.reflections ?? []).filter((r) => r.day >= range.start && r.day <= range.end).length)} sub="روز نوشته‌شده" c="bg-violet-500/10 text-violet-600" />
          <Record icon={<CheckCircle2 size={18} />} label="تسک تمام‌شده ماه" value={toFa(state.tasks.filter((t) => t.status === 'done' && t.completedAt && t.completedAt >= range.start && t.completedAt <= range.end).length)} sub="" c="bg-sky-500/10 text-sky-600" />
        </div>
        <div className="px-5 pb-5">
          <p className="mb-2 text-xs font-black text-slate-500">نمره روز در ۳۰ روز اخیر</p>
          <Bars
            data={Array.from({ length: 30 }, (_, i) => {
              const day = addDays(today, i - 29);
              const ref = (state.reflections ?? []).find((r) => r.day === day);
              return { label: toFa(toJalaali(new Date(day)).jd), value: ref?.score ?? 0, color: '#8b5cf6', dim: ref?.score == null };
            })}
            formatTick={(v) => (v > 0 ? toFa(v) : '')}
          />
        </div>
      </Card>
    </div>
  );
}

function monthRange(jy: number, jm: number) {
  const s = startOfDay(toGregorian(jy, jm, 1).getTime());
  const nm = jm === 12 ? 1 : jm + 1;
  const ny = jm === 12 ? jy + 1 : jy;
  const e = startOfDay(toGregorian(ny, nm, 1).getTime()) - 1;
  return { start: s, end: e };
}

function Kpi({ icon, label, value, sub, c }: { icon: React.ReactNode; label: string; value: string; sub?: string; c: string }) {
  return (
    <Card className="p-4">
      <span className={cx('mb-2.5 grid h-10 w-10 place-items-center rounded-2xl bg-gradient-to-br text-white', c)}>{icon}</span>
      <p className="text-[11px] font-bold text-slate-400">{label}</p>
      <p className="tabular mt-1 text-[15px] font-black text-slate-800 dark:text-white">{value}</p>
      {sub && <p className="mt-1 text-[11px] font-bold text-slate-400">{sub}</p>}
    </Card>
  );
}

function Record({ icon, label, value, sub, c }: { icon: React.ReactNode; label: string; value: string; sub: string; c: string }) {
  return (
    <div className="rounded-2xl border border-slate-100 p-3 dark:border-white/5">
      <span className={cx('mb-2 grid h-9 w-9 place-items-center rounded-xl', c)}>{icon}</span>
      <p className="text-[10px] font-bold text-slate-400">{label}</p>
      <p className="mt-0.5 truncate text-[13px] font-black text-slate-700 dark:text-slate-100">{value}</p>
      {sub && <p className="tabular text-[11px] text-slate-400">{sub}</p>}
    </div>
  );
}


