'use client';

import NextLink from 'next/link';
import { usePathname, useRouter, useSearchParams as useNextSearchParams } from 'next/navigation';
import { useCallback, useEffect, type ComponentProps, type ReactNode } from 'react';

type LinkProps = Omit<ComponentProps<typeof NextLink>, 'href'> & {
  to?: string;
  href?: string;
  children?: ReactNode;
};

export function Link({ to, href, children, ...rest }: LinkProps) {
  return (
    <NextLink href={to ?? href ?? '/'} {...rest}>
      {children}
    </NextLink>
  );
}

export function NavLink({
  to,
  className,
  children,
  ...rest
}: Omit<LinkProps, 'className'> & {
  className?: string | ((opts: { isActive: boolean }) => string);
}) {
  const path = usePathname() || '/';
  const target = to ?? '/';
  const isActive = target === '/' ? path === '/' : path === target || path.startsWith(`${target}/`);
  const cls = typeof className === 'function' ? className({ isActive }) : className;
  return (
    <NextLink href={target} className={cls} {...rest}>
      {children}
    </NextLink>
  );
}

export function useNavigate() {
  const router = useRouter();
  return useCallback((to: string) => {
    router.push(to);
  }, [router]);
}

export function useLocation() {
  const pathname = usePathname() || '/';
  return { pathname };
}

export function useSearchParams() {
  const sp = useNextSearchParams();
  return [sp] as const;
}

export function Navigate({ to, replace }: { to: string; replace?: boolean }) {
  const router = useRouter();
  useEffect(() => {
    if (replace) router.replace(to);
    else router.push(to);
  }, [to, replace, router]);
  return null;
}
