'use client';

import { useCallback, useState } from 'react';
import { usePathname } from 'next/navigation';
import { Shell } from '@/components/Shell';
import { EventModal, HabitModal, NoteModal, TaskModal, TxModal } from '@/components/forms';
import { useApp } from '@/lib/store';
import { QuickAddContext, type QuickKind } from '@/lib/quick-add';

export function AppFrame({ children }: { children: React.ReactNode }) {
  const [quick, setQuick] = useState<QuickKind | null>(null);
  const open = useCallback((k: QuickKind) => setQuick(k), []);
  const close = useCallback(() => setQuick(null), []);
  const { state, ready } = useApp();
  const fin = state.settings.financeEnabled;
  const pathname = usePathname();

  return (
    <QuickAddContext.Provider value={open}>
      <Shell onQuickAdd={open}>
        {!ready ? <BootScreen /> : children}
      </Shell>
      {fin && <TxModal open={quick === 'tx'} onClose={close} />}
      <TaskModal open={quick === 'task'} onClose={close} />
      <EventModal open={quick === 'event'} onClose={close} />
      <HabitModal open={quick === 'habit'} onClose={close} />
      <NoteModal open={quick === 'note'} onClose={close} />
      {pathname === '/finance' && ready && !fin ? null : null}
    </QuickAddContext.Provider>
  );
}

function BootScreen() {
  return (
    <div className="space-y-4">
      <div className="h-36 animate-pulse rounded-3xl bg-slate-200/70 dark:bg-white/5" />
      <div className="grid grid-cols-2 gap-3 xl:grid-cols-4">
        {Array.from({ length: 4 }).map((_, i) => (
          <div key={i} className="h-28 animate-pulse rounded-2xl bg-slate-200/70 dark:bg-white/5" />
        ))}
      </div>
      <div className="h-72 animate-pulse rounded-3xl bg-slate-200/60 dark:bg-white/5" />
    </div>
  );
}
