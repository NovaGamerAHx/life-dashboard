'use client';

import { useMemo } from 'react';
import { Link } from '@/lib/nav';
import { motion } from 'framer-motion';
import {
  CalendarDays, CheckCircle2, ChevronLeft, Flame, Heart, NotebookPen, Sparkles, Target,
} from 'lucide-react';
import { AreaChart, Bars, Donut, Legend } from '@/components/charts';
import { Card, CardHead, Progress } from '@/components/ui';
import { addDays, formatJalali, toFa, toJalaali, todayStart } from '@/lib/jalali';
import { habitStreak } from '@/lib/stats';
import { useApp } from '@/lib/store';
import { cx } from '@/lib/utils';

const fadeUp = { initial: { opacity: 0, y: 18 }, animate: { opacity: 1, y: 0 } };

const MOODS = ['😞', '😐', '🙂', '😄', '🤩'];

export function LifeOverview() {
  const { state } = useApp();
  const today = todayStart();
  const activeHabits = state.habits.filter((h) => !h.archived);

  const weekTasks = useMemo(() => {
    return Array.from({ length: 14 }, (_, i) => {
      const day = addDays(today, i - 13);
      const due = state.tasks.filter((t) => !t.backlog && t.due === day);
      const done = due.filter((t) => t.status === 'done').length;
      return { day, done, total: due.length, pct: due.length ? Math.round((done / due.length) * 100) : 0 };
    });
  }, [state.tasks, today]);

  const moodSeries = useMemo(() => {
    return Array.from({ length: 14 }, (_, i) => {
      const day = addDays(today, i - 13);
      const ref = (state.reflections ?? []).find((r) => r.day === day);
      return { day, mood: ref?.mood ?? 0, score: ref?.score ?? 0 };
    });
  }, [state.reflections, today]);

  const doneWeek = state.tasks.filter((t) => t.status === 'done' && t.completedAt && t.completedAt >= addDays(today, -7)).length;
  const reflectionsWeek = (state.reflections ?? []).filter((r) => r.day >= addDays(today, -7)).length;
  const avgMood = (() => {
    const moods = moodSeries.filter((m) => m.mood > 0);
    if (!moods.length) return null;
    return moods.reduce((a, m) => a + m.mood, 0) / moods.length;
  })();

  const habitDonut = useMemo(() => {
    return activeHabits.slice(0, 6).map((h) => {
      let c = 0;
      for (let i = 0; i < 7; i++) if (state.habitLogs[`${h.id}:${addDays(today, -i)}`]) c++;
      return { label: h.title, value: c, color: h.color };
    }).filter((x) => x.value > 0);
  }, [activeHabits, state.habitLogs, today]);

  const pinned = state.notes.filter((n) => n.pinned).slice(0, 4);
  const recentNotes = (pinned.length ? pinned : [...state.notes].sort((a, b) => b.updatedAt - a.updatedAt)).slice(0, 4);

  const focusTags = useMemo(() => {
    const m = new Map<string, number>();
    for (const t of state.tasks.filter((x) => x.status !== 'done' && !x.backlog)) {
      for (const tag of t.tags) m.set(tag, (m.get(tag) ?? 0) + 1);
    }
    return [...m.entries()].sort((a, b) => b[1] - a[1]).slice(0, 6);
  }, [state.tasks]);

  const bestStreak = activeHabits.reduce((a, h) => Math.max(a, habitStreak(h.id, state.habitLogs)), 0);
  const habitsToday = activeHabits.filter((h) => state.habitLogs[`${h.id}:${today}`]).length;

  return (
    <>
      <div className="grid grid-cols-2 gap-3 xl:grid-cols-4">
        <Mini label="انجام‌شده ۷ روز" value={`${toFa(doneWeek)} وظیفه`} sub="تمرکز روی تمام‌کردن کارها" tone="sky" icon={<CheckCircle2 size={20} />} />
        <Mini label="بازتاب این هفته" value={`${toFa(reflectionsWeek)} روز`} sub="نوشتن، دیدن، بهتر شدن" tone="violet" icon={<Heart size={20} />} />
        <Mini label="میانگین حال" value={avgMood != null ? `${MOODS[Math.round(avgMood) - 1] ?? '🙂'} ${toFa(avgMood.toFixed(1))}` : '—'} sub="از بازتاب‌های ۱۴ روز" tone="amber" icon={<Sparkles size={20} />} />
        <Mini label="عادت امروز" value={`${toFa(habitsToday)} از ${toFa(activeHabits.length)}`} sub={bestStreak ? `بهترین زنجیره ${toFa(bestStreak)} روز` : 'اولین تیک را بزن'} tone="green" icon={<Flame size={20} />} />
      </div>

      <div className="grid gap-5 xl:grid-cols-3">
        <motion.div {...fadeUp} transition={{ duration: 0.45, delay: 0.08 }} className="xl:col-span-2">
          <Card>
            <CardHead
              title="روند بهره‌وری ۱۴ روز"
              sub="درصد انجام تسک‌های هر روز + نمره ثبت‌شده"
              action={
                <Link href="/reports" className="flex items-center gap-1 text-xs font-bold text-emerald-600 hover:underline dark:text-emerald-400">
                  گزارش کامل <ChevronLeft size={14} />
                </Link>
              }
            />
            <div className="px-4 pb-2">
              <div className="mb-2 flex items-center gap-4 px-1 text-[11px] font-bold text-slate-500">
                <span className="flex items-center gap-1.5"><span className="h-2.5 w-2.5 rounded-full bg-sky-500" /> انجام تسک</span>
                <span className="flex items-center gap-1.5"><span className="h-2.5 w-2.5 rounded-full bg-violet-500" /> نمره روز</span>
              </div>
              <AreaChart
                values={weekTasks.map((d) => d.pct)}
                labels={weekTasks.map((d) => toFa(toJalaali(new Date(d.day)).jd))}
                color="#0ea5e9"
                height={150}
                idSuffix="life-prod"
              />
            </div>
            <div className="border-t border-slate-100 px-5 py-4 dark:border-white/5">
              <p className="mb-3 text-[13px] font-extrabold text-slate-700 dark:text-slate-200">نمره روزهای اخیر</p>
              <div className="flex gap-1.5 overflow-x-auto pb-1" dir="ltr">
                {moodSeries.map((d) => (
                  <div
                    key={d.day}
                    title={`${formatJalali(d.day)} — ${d.mood ? MOODS[d.mood - 1] : 'بدون بازتاب'}`}
                    className={cx(
                      'grid h-10 w-10 shrink-0 place-items-center rounded-xl border text-base',
                      d.mood ? 'border-transparent bg-violet-500/10' : 'border-slate-100 text-slate-300 dark:border-white/5',
                    )}
                  >
                    {d.mood ? MOODS[d.mood - 1] : '·'}
                  </div>
                ))}
              </div>
            </div>
          </Card>
        </motion.div>

        <div className="space-y-5">
          <motion.div {...fadeUp} transition={{ duration: 0.45, delay: 0.12 }}>
            <Card>
              <CardHead title="عادت‌های این هفته" sub="تعداد تیک در ۷ روز" />
              <div className="flex flex-col items-center gap-4 px-5 pb-5">
                <Donut
                  data={habitDonut}
                  centerTop="تیک هفته"
                  centerBottom={toFa(habitDonut.reduce((a, x) => a + x.value, 0))}
                />
                {habitDonut.length > 0
                  ? <Legend items={habitDonut} money={(v) => `${toFa(v)} روز`} />
                  : <p className="text-xs text-slate-400">این هفته هنوز تیکی ثبت نشده</p>}
              </div>
            </Card>
          </motion.div>
        </div>
      </div>

      <div className="grid gap-5 xl:grid-cols-3">
        <Card>
          <CardHead
            title="یادداشت‌های سنجاق‌شده"
            sub="ایده‌هایی که باید دم دست باشند"
            action={<Link href="/notes" className="flex items-center gap-1 text-xs font-bold text-emerald-600 hover:underline dark:text-emerald-400">همه <ChevronLeft size={14} /></Link>}
          />
          <div className="space-y-2 px-5 pb-5">
            {recentNotes.length === 0 && (
              <p className="rounded-2xl bg-slate-50 py-5 text-center text-xs text-slate-400 dark:bg-white/5">یادداشتی نیست — یک ایده بنویس ✨</p>
            )}
            {recentNotes.map((n) => (
              <Link key={n.id} href="/notes" className="block rounded-2xl border border-slate-100 px-3 py-2.5 transition hover:bg-slate-50 dark:border-white/5 dark:hover:bg-white/[0.03]">
                <p className="flex items-center gap-1.5 truncate text-[13px] font-bold text-slate-700 dark:text-slate-200">
                  <NotebookPen size={13} className="text-emerald-500" />
                  {n.title || 'بدون عنوان'}
                </p>
                {n.body && <p className="mt-1 line-clamp-2 text-[11px] leading-5 text-slate-400">{n.body}</p>}
              </Link>
            ))}
          </div>
        </Card>

        <Card>
          <CardHead title="تمرکز فعلی" sub="برچسب وظایف باز" />
          <div className="space-y-2.5 px-5 pb-5">
            {focusTags.length === 0 && <p className="rounded-2xl bg-slate-50 py-5 text-center text-xs text-slate-400 dark:bg-white/5">برچسبی روی وظایف باز نیست</p>}
            {focusTags.map(([tag, count]) => (
              <div key={tag}>
                <div className="mb-1 flex justify-between text-xs font-bold">
                  <span className="text-slate-600 dark:text-slate-300">#{tag}</span>
                  <span className="tabular text-slate-400">{toFa(count)}</span>
                </div>
                <Progress value={Math.min(100, count * 20)} color="#8b5cf6" h={6} />
              </div>
            ))}
          </div>
        </Card>

        <Card>
          <CardHead
            title="رویدادهای نزدیک"
            sub="۷ روز آینده"
            action={<Link href="/calendar" className="flex items-center gap-1 text-xs font-bold text-emerald-600 hover:underline dark:text-emerald-400">تقویم <ChevronLeft size={14} /></Link>}
          />
          <UpcomingEvents />
        </Card>
      </div>
    </>
  );
}

function Mini({ label, value, sub, tone, icon }: { label: string; value: string; sub: string; tone: 'green' | 'sky' | 'amber' | 'violet'; icon: React.ReactNode }) {
  const tones: Record<string, string> = {
    green: 'from-emerald-500 to-teal-600 shadow-emerald-600/20',
    sky: 'from-sky-500 to-blue-600 shadow-sky-600/20',
    amber: 'from-amber-500 to-orange-600 shadow-amber-600/20',
    violet: 'from-violet-500 to-purple-600 shadow-violet-600/20',
  };
  return (
    <motion.div initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.4 }}>
      <Card hover className="p-4 sm:p-5">
        <div className={cx('mb-3 grid h-11 w-11 place-items-center rounded-2xl bg-gradient-to-br text-white shadow-lg', tones[tone])}>{icon}</div>
        <p className="text-[11px] font-bold text-slate-400">{label}</p>
        <p className="tabular mt-1 text-lg font-black text-slate-800 dark:text-white">{value}</p>
        <p className="mt-1 text-[11px] font-bold text-slate-400">{sub}</p>
      </Card>
    </motion.div>
  );
}

function UpcomingEvents() {
  const { state } = useApp();
  const today = todayStart();
  const list = useMemo(() => {
    return [...state.events]
      .filter((e) => e.day >= today && e.day <= addDays(today, 7))
      .sort((a, b) => a.day - b.day || (a.time || '99').localeCompare(b.time || '99'))
      .slice(0, 5);
  }, [state.events, today]);

  if (list.length === 0) {
    return (
      <p className="mx-5 mb-5 rounded-2xl bg-slate-50 py-5 text-center text-xs text-slate-400 dark:bg-white/5">
        رویدادی در هفته پیش‌رو نیست
      </p>
    );
  }
  return (
    <ul className="space-y-2 px-5 pb-5">
      {list.map((e) => (
        <li key={e.id} className="flex items-center gap-2.5 rounded-2xl border border-slate-100 px-3 py-2.5 dark:border-white/5">
          <span className="h-9 w-1.5 shrink-0 rounded-full" style={{ background: e.color }} />
          <div className="min-w-0 flex-1">
            <p className="truncate text-[13px] font-bold text-slate-700 dark:text-slate-200">{e.title}</p>
            <p className="flex items-center gap-1 text-[11px] text-slate-400">
              <CalendarDays size={11} />
              {formatJalali(e.day, { year: false })}
              {e.time ? ` • ${e.time}` : ''}
            </p>
          </div>
        </li>
      ))}
    </ul>
  );
}

export function LifeInsights() {
  const { state } = useApp();
  const today = todayStart();
  const open = state.tasks.filter((t) => t.status !== 'done' && !t.backlog);
  const overdue = open.filter((t) => t.due != null && t.due < today).length;
  const activeHabits = state.habits.filter((h) => !h.archived);
  const habitsToday = activeHabits.filter((h) => state.habitLogs[`${h.id}:${today}`]).length;
  const reflected = (state.reflections ?? []).some((r) => r.day === today);
  const items: string[] = [];
  if (overdue > 0) items.push(`${toFa(overdue)} وظیفه عقب‌افتاده داری — اول آن‌ها را ببند.`);
  if (activeHabits.length && habitsToday < activeHabits.length) items.push(`هنوز ${toFa(activeHabits.length - habitsToday)} عادت امروز تیک نخورده.`);
  if (!reflected) items.push('بازتاب امروز خالی است؛ دو دقیقه نوشتن، فردا را شفاف می‌کند.');
  if (open.length === 0) items.push('هیچ وظیفه بازی نداری. فرصت خوبی برای یک پروژه شخصی است.');
  const pinned = state.notes.filter((n) => n.pinned).length;
  if (pinned) items.push(`${toFa(pinned)} یادداشت سنجاق‌شده دم دست است.`);
  if (items.length === 0) items.push('همه‌چیز مرتب به‌نظر می‌رسد. همین ریتم را نگه دار.');

  return (
    <Card>
      <CardHead title="پیشنهاد امروز" sub="بر اساس وظایف، عادت‌ها و بازتاب‌ها" />
      <ul className="space-y-2 px-5 pb-5">
        {items.slice(0, 4).map((s, i) => (
          <li key={i} className="flex items-start gap-2.5 rounded-2xl bg-emerald-500/[0.06] px-3.5 py-3 text-[12px] leading-6 text-slate-600 ring-1 ring-emerald-500/15 dark:text-slate-300">
            <Target size={16} className="mt-0.5 shrink-0 text-emerald-500" />
            {s}
          </li>
        ))}
      </ul>
    </Card>
  );
}

export function WeekBars() {
  const { state } = useApp();
  const today = todayStart();
  const data = Array.from({ length: 7 }, (_, i) => {
    const day = addDays(today, i - 6);
    const done = state.tasks.filter((t) => t.status === 'done' && t.completedAt && t.completedAt >= day && t.completedAt < addDays(day, 1)).length;
    return { label: toFa(toJalaali(new Date(day)).jd), value: done, color: i === 6 ? '#10b981' : '#6ee7b7' };
  });
  return (
    <Card>
      <CardHead title="تسک‌های تمام‌شده ۷ روز" sub="تعداد کارهایی که هر روز به اتمام رسید" />
      <div className="px-5 pb-5">
        <Bars data={data} formatTick={(v) => (v > 0 ? toFa(v) : '')} />
      </div>
    </Card>
  );
}


