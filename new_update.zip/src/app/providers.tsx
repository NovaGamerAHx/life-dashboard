'use client';

import type { ReactNode } from 'react';
import { AppFrame } from '@/components/AppFrame';
import { AppProvider } from '@/lib/store';

export function Providers({ children }: { children: ReactNode }) {
  return (
    <AppProvider>
      <AppFrame>{children}</AppFrame>
    </AppProvider>
  );
}
