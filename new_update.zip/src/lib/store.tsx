'use client';

import { createContext, useCallback, useContext, useEffect, useMemo, useRef, useState, type ReactNode } from 'react';
import type {
  AppSettings, AppState, Budget, CalEvent, DayReflection, Habit, MoneyUnit, Note, Task,
  TaskCategory, TaskStatus, ThemeMode, Transaction,
} from './types';
import { blankState, seedState } from './seed';
import { uid } from './utils';

interface AppContextValue {
  state: AppState;
  ready: boolean;
  saving: boolean;
  lastSaved: number | null;
  persistError: string | null;
  addTransaction: (t: Omit<Transaction, 'id' | 'createdAt'>) => void;
  updateTransaction: (id: string, patch: Partial<Transaction>) => void;
  deleteTransaction: (id: string) => void;
  addTask: (t: Omit<Task, 'id' | 'createdAt' | 'completedAt'>) => void;
  updateTask: (id: string, patch: Partial<Task>) => void;
  deleteTask: (id: string) => void;
  moveTask: (id: string, status: TaskStatus) => void;
  addEvent: (e: Omit<CalEvent, 'id' | 'createdAt'>) => void;
  updateEvent: (id: string, patch: Partial<CalEvent>) => void;
  deleteEvent: (id: string) => void;
  addHabit: (h: Omit<Habit, 'id' | 'createdAt'>) => void;
  updateHabit: (id: string, patch: Partial<Habit>) => void;
  deleteHabit: (id: string) => void;
  toggleHabit: (habitId: string, dayTs: number) => void;
  addNote: (n: Omit<Note, 'id' | 'createdAt' | 'updatedAt'>) => void;
  updateNote: (id: string, patch: Partial<Note>) => void;
  deleteNote: (id: string) => void;
  saveReflection: (r: Omit<DayReflection, 'updatedAt'>) => void;
  deleteReflection: (day: number) => void;
  addTaskCat: (name: string, color: string) => void;
  updateTaskCat: (id: string, patch: Partial<TaskCategory>) => void;
  deleteTaskCat: (id: string) => void;
  setBudget: (b: Budget) => void;
  deleteBudget: (category: string) => void;
  addCategory: (kind: 'expense' | 'income', name: string) => boolean;
  deleteCategory: (kind: 'expense' | 'income', name: string) => void;
  setTheme: (t: ThemeMode) => void;
  setUnit: (u: MoneyUnit) => void;
  setName: (name: string) => void;
  setFinanceEnabled: (v: boolean) => void;
  setWeekStart: (v: 'sat' | 'mon') => void;
  setCalSystem: (v: 'jalali' | 'gregorian') => void;
  setHabitArchived: (id: string, archived: boolean) => void;
  importState: (s: AppState) => boolean;
  resetDemo: () => void;
  clearAll: () => void;
}

const AppContext = createContext<AppContextValue | null>(null);

function sanitize(s: unknown): AppState | null {
  if (!s || typeof s !== 'object') return null;
  const o = s as Partial<AppState>;
  if (o.version !== 1) return null;
  if (!Array.isArray(o.transactions) || !Array.isArray(o.tasks) || !Array.isArray(o.events)) return null;
  if (!Array.isArray(o.habits) || !Array.isArray(o.notes) || !Array.isArray(o.budgets)) return null;
  const base = blankState();
  return {
    ...base,
    ...(o as AppState),
    taskCats: Array.isArray(o.taskCats) && o.taskCats.length > 0 ? o.taskCats as TaskCategory[] : base.taskCats,
    reflections: Array.isArray(o.reflections) ? (o.reflections as DayReflection[]) : [],
    settings: {
      ...base.settings,
      ...(o.settings ?? {}),
      financeEnabled: (o.settings as Partial<AppSettings> | undefined)?.financeEnabled ?? false,
      weekStart: (o.settings as Partial<AppSettings> | undefined)?.weekStart ?? 'sat',
      calSystem: (o.settings as Partial<AppSettings> | undefined)?.calSystem ?? 'jalali',
    },
    tasks: ((o.tasks as Task[] | undefined) ?? []).map((t) => ({
      ...t,
      backlog: t.backlog ?? t.due == null,
      time: t.time ?? '',
      durationMin: t.durationMin ?? 60,
      urgent: t.urgent ?? t.priority === 'high',
      deadline: t.deadline ?? null,
      actualMin: t.actualMin ?? undefined,
      result: t.result ?? undefined,
      subtasks: Array.isArray(t.subtasks) ? t.subtasks : [],
      tags: Array.isArray(t.tags) ? t.tags : [],
    })),
  };
}

export function AppProvider({ children }: { children: ReactNode }) {
  const [state, setState] = useState<AppState>(() => blankState());
  const [ready, setReady] = useState(false);
  const [saving, setSaving] = useState(false);
  const [lastSaved, setLastSaved] = useState<number | null>(null);
  const [persistError, setPersistError] = useState<string | null>(null);
  const skipSave = useRef(true);
  const timer = useRef<ReturnType<typeof setTimeout> | null>(null);

  useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        const res = await fetch('/api/state', { cache: 'no-store' });
        const data = await res.json();
        if (cancelled) return;
        if (data?.ok && data.state) {
          const clean = sanitize(data.state);
          skipSave.current = true;
          setState(clean ?? seedState());
        } else {
          skipSave.current = true;
          setState(seedState());
        }
      } catch {
        if (!cancelled) {
          skipSave.current = true;
          setState(seedState());
          setPersistError('اتصال به سرور برقرار نشد؛ داده‌ها موقتاً فقط در این جلسه نگه داشته می‌شوند.');
        }
      } finally {
        if (!cancelled) setReady(true);
      }
    })();
    return () => { cancelled = true; };
  }, []);

  useEffect(() => {
    if (!ready) return;
    if (skipSave.current) {
      skipSave.current = false;
      return;
    }
    if (timer.current) clearTimeout(timer.current);
    timer.current = setTimeout(async () => {
      setSaving(true);
      try {
        const res = await fetch('/api/state', {
          method: 'PUT',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(state),
        });
        const data = await res.json();
        if (!data?.ok) throw new Error(data?.error || 'save failed');
        setPersistError(null);
        setLastSaved(Date.now());
      } catch {
        setPersistError('ذخیره‌سازی روی سرور ناموفق بود. اتصال را بررسی کنید.');
      } finally {
        setSaving(false);
      }
    }, 450);
    return () => { if (timer.current) clearTimeout(timer.current); };
  }, [state, ready]);

  useEffect(() => {
    const root = document.documentElement;
    const mode = state.settings.theme;
    const apply = (dark: boolean) => root.classList.toggle('dark', dark);
    try {
      const hint = mode === 'system'
        ? (window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light')
        : mode;
      localStorage.setItem('life_theme_hint', hint);
    } catch { /* ignore */ }
    if (mode === 'system') {
      const mq = window.matchMedia('(prefers-color-scheme: dark)');
      apply(mq.matches);
      const fn = (e: MediaQueryListEvent) => apply(e.matches);
      mq.addEventListener('change', fn);
      return () => mq.removeEventListener('change', fn);
    }
    apply(mode === 'dark');
  }, [state.settings.theme]);

  const persistNow = useCallback((next: AppState) => {
    skipSave.current = true;
    setState(next);
    void fetch('/api/state', {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(next),
    }).then(async (res) => {
      const data = await res.json().catch(() => null);
      if (!data?.ok) throw new Error('save failed');
      setPersistError(null);
      setLastSaved(Date.now());
    }).catch(() => {
      setPersistError('ذخیره‌سازی روی سرور ناموفق بود.');
    });
  }, []);

  const value = useMemo<AppContextValue>(() => ({
    state,
    ready,
    saving,
    lastSaved,
    persistError,
    addTransaction: (t) =>
      setState((s) => ({ ...s, transactions: [{ ...t, id: uid('tx'), createdAt: Date.now() }, ...s.transactions] })),
    updateTransaction: (id, patch) =>
      setState((s) => ({ ...s, transactions: s.transactions.map((x) => (x.id === id ? { ...x, ...patch } : x)) })),
    deleteTransaction: (id) =>
      setState((s) => ({ ...s, transactions: s.transactions.filter((x) => x.id !== id) })),

    addTask: (t) =>
      setState((s) => ({
        ...s,
        tasks: [{ ...t, id: uid('task'), createdAt: Date.now(), completedAt: null }, ...s.tasks],
      })),
    updateTask: (id, patch) =>
      setState((s) => ({
        ...s,
        tasks: s.tasks.map((x) => {
          if (x.id !== id) return x;
          const next = { ...x, ...patch };
          if (patch.status && patch.status !== x.status) {
            next.completedAt = patch.status === 'done' ? Date.now() : null;
          }
          return next;
        }),
      })),
    deleteTask: (id) => setState((s) => ({ ...s, tasks: s.tasks.filter((x) => x.id !== id) })),
    moveTask: (id, status) =>
      setState((s) => ({
        ...s,
        tasks: s.tasks.map((x) =>
          x.id === id ? { ...x, status, completedAt: status === 'done' ? Date.now() : null } : x,
        ),
      })),

    addEvent: (e) =>
      setState((s) => ({ ...s, events: [...s.events, { ...e, id: uid('ev'), createdAt: Date.now() }] })),
    updateEvent: (id, patch) =>
      setState((s) => ({ ...s, events: s.events.map((x) => (x.id === id ? { ...x, ...patch } : x)) })),
    deleteEvent: (id) => setState((s) => ({ ...s, events: s.events.filter((x) => x.id !== id) })),

    addHabit: (h) =>
      setState((s) => ({ ...s, habits: [...s.habits, { ...h, id: uid('h'), createdAt: Date.now() }] })),
    updateHabit: (id, patch) =>
      setState((s) => ({ ...s, habits: s.habits.map((x) => (x.id === id ? { ...x, ...patch } : x)) })),
    deleteHabit: (id) =>
      setState((s) => {
        const logs = { ...s.habitLogs };
        for (const k of Object.keys(logs)) if (k.startsWith(id + ':')) delete logs[k];
        return { ...s, habits: s.habits.filter((x) => x.id !== id), habitLogs: logs };
      }),
    toggleHabit: (habitId, day) =>
      setState((s) => {
        const key = `${habitId}:${day}`;
        const logs = { ...s.habitLogs };
        if (logs[key]) delete logs[key];
        else logs[key] = true;
        return { ...s, habitLogs: logs };
      }),

    addNote: (n) =>
      setState((s) => {
        const now = Date.now();
        return { ...s, notes: [{ ...n, id: uid('n'), createdAt: now, updatedAt: now }, ...s.notes] };
      }),
    updateNote: (id, patch) =>
      setState((s) => ({
        ...s,
        notes: s.notes.map((x) => (x.id === id ? { ...x, ...patch, updatedAt: Date.now() } : x)),
      })),
    deleteNote: (id) => setState((s) => ({ ...s, notes: s.notes.filter((x) => x.id !== id) })),

    saveReflection: (r) =>
      setState((s) => {
        const rest = (s.reflections ?? []).filter((x) => x.day !== r.day);
        return { ...s, reflections: [...rest, { ...r, updatedAt: Date.now() }] };
      }),
    deleteReflection: (day) =>
      setState((s) => ({ ...s, reflections: (s.reflections ?? []).filter((x) => x.day !== day) })),

    addTaskCat: (name, color) =>
      setState((s) => ({
        ...s,
        taskCats: [...(s.taskCats ?? []), { id: uid('tc'), name: name.trim(), color }],
      })),
    updateTaskCat: (id, patch) =>
      setState((s) => {
        const old = (s.taskCats ?? []).find((c) => c.id === id);
        const nextCats = (s.taskCats ?? []).map((c) => (c.id === id ? { ...c, ...patch } : c));
        let tasks = s.tasks;
        if (old && patch.name && patch.name.trim() && patch.name.trim() !== old.name) {
          tasks = s.tasks.map((t) => ({
            ...t,
            tags: t.tags.map((tg) => (tg === old.name ? patch.name!.trim() : tg)),
          }));
        }
        return { ...s, taskCats: nextCats, tasks };
      }),
    deleteTaskCat: (id) =>
      setState((s) => {
        const gone = (s.taskCats ?? []).find((c) => c.id === id);
        return {
          ...s,
          taskCats: (s.taskCats ?? []).filter((c) => c.id !== id),
          tasks: gone ? s.tasks.map((t) => ({ ...t, tags: t.tags.filter((tg) => tg !== gone.name) })) : s.tasks,
        };
      }),

    setBudget: (b) =>
      setState((s) => {
        const rest = s.budgets.filter((x) => x.category !== b.category);
        return { ...s, budgets: [...rest, b] };
      }),
    deleteBudget: (category) =>
      setState((s) => ({ ...s, budgets: s.budgets.filter((x) => x.category !== category) })),
    addCategory: (kind, name) => {
      const n = name.trim();
      if (!n) return false;
      let ok = false;
      setState((s) => {
        const key = kind === 'expense' ? 'expenseCats' : 'incomeCats';
        if (s[key].includes(n)) return s;
        ok = true;
        return { ...s, [key]: [...s[key], n] };
      });
      return ok;
    },
    deleteCategory: (kind, name) =>
      setState((s) => {
        const key = kind === 'expense' ? 'expenseCats' : 'incomeCats';
        return { ...s, [key]: s[key].filter((c) => c !== name) };
      }),

    setTheme: (theme) => setState((s) => ({ ...s, settings: { ...s.settings, theme } })),
    setUnit: (unit) => setState((s) => ({ ...s, settings: { ...s.settings, unit } })),
    setName: (name) => setState((s) => ({ ...s, profile: { name } })),
    setFinanceEnabled: (v) => setState((s) => ({ ...s, settings: { ...s.settings, financeEnabled: v } })),
    setWeekStart: (v) => setState((s) => ({ ...s, settings: { ...s.settings, weekStart: v } })),
    setCalSystem: (v) => setState((s) => ({ ...s, settings: { ...s.settings, calSystem: v } })),
    setHabitArchived: (id, archived) =>
      setState((s) => ({ ...s, habits: s.habits.map((h) => (h.id === id ? { ...h, archived } : h)) })),

    importState: (ns) => {
      const clean = sanitize(ns);
      if (!clean) return false;
      persistNow(clean);
      return true;
    },
    resetDemo: () => persistNow(seedState()),
    clearAll: () => persistNow({ ...blankState(), settings: state.settings, profile: state.profile }),
  }), [state, ready, saving, lastSaved, persistError, persistNow]);

  return (
    <AppContext.Provider value={value}>
      {persistError && (
        <div className="fixed bottom-4 left-1/2 z-[100] w-[calc(100%-2rem)] max-w-xl -translate-x-1/2 rounded-2xl border border-amber-500/30 bg-amber-50 px-4 py-3 text-xs font-bold leading-6 text-amber-800 shadow-2xl dark:bg-amber-950 dark:text-amber-200">
          ⚠️ {persistError}
        </div>
      )}
      {children}
    </AppContext.Provider>
  );
}

export function useApp(): AppContextValue {
  const ctx = useContext(AppContext);
  if (!ctx) throw new Error('useApp باید داخل AppProvider استفاده شود');
  return ctx;
}
